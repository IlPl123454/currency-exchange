package org.plenkovii.exception;

public class InvalidParameterexception extends RuntimeException {
    public InvalidParameterexception(String message) {
        super(message);
    }
}
