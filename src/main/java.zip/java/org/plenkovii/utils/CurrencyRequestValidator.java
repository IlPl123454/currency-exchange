package org.plenkovii.utils;

public class CurrencyRequestValidator {
}
